# Missile Tech Website 🚀

A simple static website themed around missile technology and defense systems.

## Features
- Clean dark UI
- Technology-focused layout
- Easy to customize

## How to Run
Open `index.html` in your browser.

## Note
This project is for educational and portfolio purposes only.
